<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="connexion.css">
        <link rel="icon" href="images/Blanc-final.png" type="image/png">
    </head>
    <?php
    include("header.php")
?>

<body>
	<main>
            <div class="connexion">
                <div class= se_connecter>
                <h2 class="connexion"><a href="#">Connexion</a></h2>
                <form action="client.html" method="post" class="row g-3">
                    <div class="champs">
                        <div>
                            <div class="email">
                                <input id="email" type="email" name='email' type="email" class="form-control" placeholder="Adresse mail">
                            </div>
                        </div>
                        <div id="mdp1">
                            <input mot de passe="" id="password" name="password" class="form-control" type="password" placeholder="Mot de passe">
                            <p><a id="mot_de_passe" href="mot_de_passe.php">Mot de passe oublié</a></p>
                        </div>
                    </div>
                    <div>
                        <input type="checkbox" id="rester_connecté" name="rester_connecté">
                        <label for="rester_connecté-identification">Rester connecté</label>
                    </div>
                    <div class="bouton_connexion">
                        <button id="BoutonConnexion" class:"button">Se Connecter </button>
                    </div>
                </form>
            </div>
            <span class="vertical-line"></span>
            <div class= "s-inscrire">
                <h2 class="inscription"><a href="#">Inscription</a></h2>
                <form action="client.html" method="post" class="row g-3">
                    <div class="champs">
                        <div class="bouton_inscription">
                            <input type=button onClick="location.href='inscription.php'"value='S&#039inscrire'>
                        </div>
                    </div>
                </form>
                <h3>Se connecter avec :</h3>
                <div class="images">
                    <a href=""><img src="image/logo_google.png" alt=""></a>
                    <a href=""><img src="image/logo_apple.png" alt=""></a>
                    <a href=""><img src="image/logo_metamask.png" alt=""></a>
                    <a href=""><img src="image/logo_coinbase.png" alt=""></a>
                    <a href=""><img src="image/logo_binance.png" alt=""></a>
                </div>
                
            </div>

            <div class="stars">
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
</div>

<?php
// Vérification de l'envoi de données au serveur
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $errors = 0;


    $email = $_POST['email'];
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo '<div class="alert alert-danger" role="alert">L\'adresse e-mail est invalide !</div>';
        $errors++;
    }

    $password = $_POST['password'];
    if (strlen($password) < 10) {
        echo '<div class="alert alert-danger" role="alert">Votre message doit faire au minimum 10 caractères !</div>';
        $errors++;
    }


    if ($errors === 0) {

    
        // Requete dans la BDD pour vérifier l'utilisateur
        $query = $pdo->prepare("INSERT INTO CONTACT(firstName, lastName, email, message) VALUES(?,?,?,?)");
        $query->bindValue(1, $firstName);
        $query->bindValue(2, $lastName);
        $query->bindValue(3, $email);
        $query->bindValue(4, $password);
        $query->execute();

      

        echo '<div class="alert alert-success" role="alert">Votre message à été envoyé avec succès !</div>';

        
        unset($email);
        unset($pass);

    
    }
}

?> 
	</main>
</body>
</html>