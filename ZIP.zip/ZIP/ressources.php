<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
	<title>.Atom.</title>
    <link rel="icon" href="images/Blanc-final.png" type="image/png">
</head>

<body>
    <style>
        <?php
            require ('./ressources.css');
        ?>
    </style>
    <?php
    require ('header.php');
    ?>
    <main>
            <div class="rubriques">
                <div class='ligne'>
                    <a href="actu.php">
                        <div class='rubrique'>
                            <img src="image/news.png" alt="">
                            <div class='titre' id='actualités'>
                                <h3>Actualités</h3>
                                <p>Retrouver dans cette rubrique, l'ensemble des actualités autour du monde des NFT et de la cryptomonnaie Avalanche (AVAX)</p>
                            </div>
                        </div>
                    </a>
                    <a href="marketplace.php">
                        <div class='rubrique'>
                            <img src="image/avalanche.png" alt="">
                            <div class="titre" id="cours">
                                <h3>Cours AVAX</h3>
                                <p>Découvrez dans cette rubrique, Avalanche (AVAX), une cryptomonnaie très prometteuse avec son fonctionnement et son cours</p>
                            </div>
                            <p></p>  
                        </div>
                    </a>
                    <a href="tuto.php">
                        <div class='rubrique'>
                            <img src="images/collection5/assassin.png" alt="">
                            <div class='titre' id='samurai'>
                                <h3>Tutoriels</h3>
                                <p>Découvrez nos tutos sur l'achat, la vente ou encore la création de NFT. <br><p align-items: center;>Rejoignez la communauté .ATOM. !</p>
                            </div>
                        </div>
                    </a>
                </div>
                </div>
            </div>
        </div>
    </main>    
</body>
</html>
