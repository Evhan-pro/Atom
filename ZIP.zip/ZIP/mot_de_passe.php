<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>.Atom.</title>
    <link rel="icon" href="images/Blanc-final.png" type="image/png">
</head>

<body>
    <style>
        <?php
            require ('mot_de_passe.css');
        ?>
    </style>
	<main>
        <div class="changement">
            <div class="creer_compte">
                <form action="client.html" method="post" class="row g-3">
                    <div class="champs">
                        <h1>Vous avez égaré votre mot de passe ?</h1>
                            <h2>Pas de soucis entrez votre adresse mail et votre numéro de téléphone pour le changer</h2>
                            <div>
                            <div>
                                    <input id="mail-creation" name="email" type="email" placeholder="Adresse mail"required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$">
                                    <span class="validity"></span>
                            </div>
                            <div>
                                    <input id="tel" name="tel" type="tel" placeholder="Numéro de téléphone (xx xx xx xx xx)"required pattern="[0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2}">
                                    <span class="validity"></span>
                            </div>
                            <div class="bouton_vers_connexion">
                                <input type=button onClick="location.href='inscription.php" value="Envoyer">
                            </div>
                </form>
            </div>
        </div>
	</main>
    <div class="stars">
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
</div>
    
</body>
</html>
