<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
	<title>.Atom.</title>
    <link rel="icon" href="image/logo_qui_claque_sa_mere.png" type="image/png">
</head>

<body>
    <?php
    require ('header.php');
    ?>
    <main>
        <style>
            <?php
                require ('./creer_nft.css');
            ?>
        </style>
        <div class='fond'>
                <h1>C'est à ton tour de jouer !</h1>
                <h2>Montre ta créativité avec tes NFT</h2>
            <div class="dropzone">
                <form action="/file-upload" >
                    <div class="recherche">
                        <input name="file" type="file" multiple />
                    </div>
                </form>
            </div>
            <div class='informations'>

            <form action="compte.php" method="post" class="row g-3">
                    <div class="champs">
                        <div class="nom_collection">
                            <input id="name" name="name collection" type="text" placeholder="Nom de la collection">
                        </div>
                        <textarea id="description_collection" name="desc_collection"rows="5" cols="33" placeholder="Description de votre collection"></textarea>
                        <div class="nom_NFT">
                            <input id="name_NFT" name="name NFT" type="text" placeholder="Nom de la création"/>
                        </div>
                        <textarea id="description_creation" name="desc_creation"rows="5" cols="33" placeholder="Description de votre création"></textarea>
                        
                        <div class="prix">
                            <input id="price" name="prix de la création" type="number" placeholder="Prix de vente en AVAX">
                            <span class="validity"></span>
                        </div>
                        
                        <div class="pseudo">
                            <input id="pseudo" name="pseudo du créateur" type="text" placeholder="Pseudo du créateur">
                            <span class="validity"></span>
                        </div>    
                    </div>
                </form>
            </div>
            <select class="blockchain">
                            <option value="">--Blockchain à choisir--</option>
                            <option value="AVAX">Avalanche</option>
                            <option value="ETH">Ethereum</option>
                        </select>
            <div class="bouton">
                <input type=button onClick="location.href='connexion.php'"value='Mettre en ligne'>
            </div>
        </div>
    </main>
    <?php
    require ('footer.php');
    ?> 
</body>
</html>
