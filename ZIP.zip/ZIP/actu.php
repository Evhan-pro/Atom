<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
	<title>.Atom.</title>
    <link rel="icon" href="images/Blanc-final.png" type="image/png">
</head>

<body>
    <style>
        <?php
            require ('./actu.css');
        ?>
    </style>
    <?php
    require ('header.php');
    ?>
    <main>
            <div class="rubriques">
                <div class='ligne'>
                    <h1>Actualités</h1>
                    <a href="https://markets.businessinsider.com/news/currencies/bored-ape-yacht-club-top-selling-nft-sales-cryptopunks-meebits-2022-3">
                        <div class='rubrique'>
                        <h2>Bored Ape Yacht Club a fait grimper les ventes de NFT à 300 millions de dollars au cours de la semaine dernière</h2>
                            <img src="image/article1.png" alt="">
                            <div class='titre' id='actualités'>
                                <p>Ce sont les 5 collections numériques les plus vendues. Le volume total des ventes de NFT a atteint 24 milliards de dollars au cours de la dernière année alors que les artistes, les investisseurs et les entrepreneurs descendent sur l'espace Web3 naissant.</p>
                            </div>
                        </div>
                    </a>
                    <a href="https://www.theblockcrypto.com/post/139841/azuki-nft-sells-for-record-1-4-million?utm_source=basicrss&utm_medium=rss">
                        <div class='rubrique'>
                            <h2>Azuki NFT sells for record $1.4 million</h2>
                            <img src="image/article2.png" alt="">
                            <div class="titre" id="cours">
                                <p>Azuki #9605 vient de vendre pour 420,7 ETH sur le marché NFT.ATOM.</p>
                            </div> 
                        </div>
                    </a>
                    <a href="https://decrypt.co/96244/world-of-women-galaxy-ethereum-nft-drop-79m">
                        <div class='rubrique'>
                            <h2>World of Women Galaxy Ethereum NFT Drop génère 79 millions de dollars en un jour</h2>
                            <img src="image/article3.png" alt="">
                            <div class='titre' id='samurai'>
                                
                                <p>Le projet croissant World of Women NFT prend une tournure de science-fiction avec sa nouvelle collection Galaxy - et il se vend comme des petits pains.</p>
                            </div>
                        </div>
                    </a>
                </div>
                </div>
            </div>
        </div>
    </main>    
</body>
</html>
