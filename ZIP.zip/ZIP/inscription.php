


<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>.Atom.</title>
    <link rel="icon" href="images/Blanc-final.png" type="image/png">
</head>

<body>
    <style>
        <?php
            require ('inscription.css');
        ?>
        <?php
            require('nft.sql')
        ?>
    </style>
	<main>
        <div class="connexions">
            <div class="creer_compte">
            <h1 class="inscription"><a href="inscription.php">Inscription</a></h1>
                <h2>Rejoignez la Team !</h2>
                <form action="client.html" method="post" class="row g-3">
                    <div class="champs">
                        <div>
                            <input id="name" name="name" type="text" placeholder="Nom">
                            <input id="lastname" name="lastname" type="text" placeholder="Prénom">
                        </div>
                        <div>
                            <div class="mail">
                                <input id="mail-creation" name="email" type="email" placeholder="Adresse mail" required patern="[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+.[a-zA-Z.]{2,15}"/>
                            </div>
                        </div>
                            <div>
                                <input id="tel" name="tel" type="tel" placeholder="Numéro de téléphone (xx xx xx xx xx)"required pattern="[0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2}">
                                <span class="validity"></span>
                            </div>
                        <div>
                            <input id="mdp-creation" name="password" type="password" placeholder="Mot de passe">
                        </div>
                    </div>
                    <div class="conditions">
                        <input type="checkbox" id="rester_connecté-creation" name="rester_connecté">
                        <label for="confidentialité">J’ai lu et j’accepte les <a href="">conditions d’utilisation et la politique
                            <br>de protection des données personnelles</a></label>
                    </div>
                    <div class="bouton">
                        <input id ="creation" type=button onClick="location.href='connexion.php'"value='S&#39;inscrire'>
                    </div>
                </form>
            </div>
        </div>
        <div class="stars">
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
</div>
	</main>
</body>
</html>
