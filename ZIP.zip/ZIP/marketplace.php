<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
	<title>.Atom.</title>
    <link rel="icon" href="image/logo_qui_claque_sa_mere.png" type="image/png">
</head>

<body>
    <?php
    require ('header.php');
    ?>
    <main>
        <style>
            <?php
                require ('./marketplace.css');
            ?>
        </style>
        <div class='market'>
            <div class="titre">
                <img src="image/avax.png" alt="Icon du logo Avalanche" width="10%">
                <h1>Avalanche (AVAX)</h1>
            </div>
            <nav class="liens">
                <a href="#cest_quoi">C'est quoi Avalanche ?</a>
                <a href="#pourquoi_elle">Pourquoi avoir choisi cette cryptomonnaie ?</a>
                <a href="#comment_acheter">Comment se procurer de l'AVAX ?</a>
                <a href="#cours">Cours AVAX</a>
            </nav>
            <img id="image"src="image/illustration.jpeg" alt="Illustration de l'article" width="80%">
            
            <div class='texte'>
                <h2 id="cest_quoi">C'est quoi Avalanche ?</h2>
                <p>Avalanche (AVAX) est une plateforme qui a été lancée en 200 par Ava Labs. Compatible avec les contrats intelligents, elle vise à fournir une solution blockchain évolutive, tout en maintenant la décentralisation et la sécurité. Aussi, elle se concentre sur la réduction des coûts, la rapidité des transactions et l’écocompatibilité. <br>Depuis quelques années, Avalanche (AVAX) est devenue très populaire. C’est ainsi que la valeur d’Avalanche TVL est montée à 8,41 milliards de dollars et elle continue d’augmenter à travers les applications décentralisées (DApp) d’Avalanche. <br>Avec Avalanche, les gens peuvent créer un nombre illimité de blockchains personnalisées. Cependant, il y a un élément à prendre en compte : afin d’exploiter une blockchain sur Avalanche, il faut disposer d’un abonnement.</p>
                <h2 id="pourquoi_elle">Pourquoi avoir choisi cette cryptomonnaie ?</h2>
                <p>Avalanche fera partie de l’avenir de la blockchain et sans aucun doute du Web 3.0. La plateforme à levée 230 millions de dollars grâce à la vente en 2021 de son token natif, l’AVAX, et elle ne compte pas s’arrêter là. Parmi les bailleurs de fonds on peut citer : Polychain et Three Arrows Capital. Compte tenu de leur expertise, il est évident que ces derniers ont vu un potentiel important dans le projet.<br> En outre, grâce à la flambée du cours du token au cours des derniers mois, et surtout après l’émission des AVAX restants prévue pour début 2022, Avalanche pourrait dépasser ses concurrents dans leur ruée vers un “Internet de blockchain” et vers la simplification de la finance.<br> Actuellement, AVAX est à la 10ème position du classement des plus grosses cryptomonnaies. </p>
                <p id="lien"><br>Pour plus d'information, vous pouvez consulter le site d'<a href="https://www.avax.network/">Avalanche</a>.</p>
                <h2 id="comment_acheter">Comment se procurer de l'AVAX ?</h2>
                <p>Il faut poccéder un wallet (un portefeuille de cryptomonnaie)<br><br>Conseil: Nous vous conseillons la plateforme <a href="https://www.coinhouse.com/">Coinhouse</a>, le leader français dans ce milieu, très fiable, simple d'utilisation et avec des frais modérés (de 2,49% à 3.49%) il ne pourra que vous séduire. Sinon, nous vous conseillons <a href="https://www.coinbase.com">Coinbase</a>, leader mondial et avec des frais modéré également (de 1,49% à 3,99%).<br><br>Attention toutes les plateformes ne possèdes pas l'ensemble des cryptomonnaies donc vérifiez bien !</p>
                <h2 id="cours"> Cours AVAX </h2>
            </div>
            <div class='marketplace'>
                <div class='courbe'>
                    <script src="https://widgets.coingecko.com/coingecko-coin-compare-chart-widget.js"></script>
                    <coingecko-coin-compare-chart-widget  coin-ids="avalanche-2" currency="eur" locale="fr" type="price"></coingecko-coin-compare-chart-widget>
                </div>
                <div class='crypto'>
                    <script src="https://widgets.coingecko.com/coingecko-coin-ticker-widget.js"></script>
                    <coingecko-coin-ticker-widget  coin-id="avalanche-2" currency="eur" locale="fr" width="0"></coingecko-coin-ticker-widget>
                </div>
            </div>
        </div>
    </main>
    <?php
    require ('footer.php');
    ?> 
</body>
</html>