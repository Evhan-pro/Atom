<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
	<title>.Atom.</title>
    <link rel="icon" href="images/Blanc-final.png" type="image/png">
</head>

<body>
    <style>
        <?php
            require ('./tuto.css');
        ?>
    </style>
    <?php
    require ('header.php');
    ?>
    <main>
            <div class="rubriques">
                <div class='ligne'>
                    <h1>Tutoriels</h1>
                        <div class='rubrique'>
                            <h2>Comment créer une NFT ?</h2>
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/CXtEXfYrjy0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                        <div class='titre'>
                                            <p>Retrouvez le travail d'un de nos créateurs .ATOM. à travers un timelapse. Ce tuto vous montra la réalisation d'un NFT sur Photoshop.</p>
                                        </div>
                        </div>
                        <div class='rubrique'>
                            <h2>Comment s'inscrire sur Coinbase ?</h2>
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/ENHQgEtQrjY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                        <div class="titre">
                                            <p>Rentrer dans le monde de la cryptomonnaie avec Coinbase !!!<br><br> Ce tuto vous montrera comment vous inscrire et sécuriser au maximum votre compte</p>
                                        </div> 
                        </div>
                        <div class='rubrique'>
                            <h2>Comment acheter et revendre des NFT ?</h2>
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/wcRSFhHOtOk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <div class='titre'>  
                                <p>Venez découvrir comment investir dans ce monde surprenant des NFT et devenez rentable sur la durée !</p>
                            </div>
                        </div>
                    </a>
                </div>
                </div>
            </div>
        </div>
    </main>    
</body>
</html>
